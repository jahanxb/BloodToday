<?php
require_once('config.php');
class USER
{
private $conn;
public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }

	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}

	public function register($email,$phoneNo,$password)
	{
		try
		{
			$new_password = password_hash($password, PASSWORD_DEFAULT);
$stmt = $this->conn->prepare("INSERT INTO user(email,phoneNo,password)
		                                               VALUES(:email, :phoneNo, :password)");
			$stmt->bindparam(":email", $email);
			$stmt->bindparam(":phoneNo", $phoneNo);
			$stmt->bindparam(":password", $new_password);

			$stmt->execute();

			return $stmt;
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	public function doLogin($email,$password)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT userID, email, password FROM user WHERE email=:email");
			$stmt->execute(array(':email'=>$email));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			if($stmt->rowCount() == 1)
			{
				if(password_verify($password, $userRow['password']))
				{
					$_SESSION['user_session'] = $userRow['userID'];
					return true;
				}
				else
				{

					return false;
				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	public function is_loggedin()
	{
		if(isset($_SESSION['user_session']))
		{
			return true;
		}
	}

public function redirect($url)
	{
    try {
	     header("location: ".$url);
}
catch(PDOException $e){ echo $e->getMessage();  }
  }

public function doLogout()
	{
		session_destroy();
		unset($_SESSION['user_session']);
		return true;
	}
}
?>
