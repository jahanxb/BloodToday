-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2016 at 12:49 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blooddbs`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `AddressID` int(11) NOT NULL,
  `Country_CountryID` int(11) NOT NULL,
  `Province_ProvinceID` int(11) NOT NULL,
  `City_CityID` int(11) NOT NULL,
  `CityArea_CityAreaID` int(11) NOT NULL,
  `person_PersonID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`AddressID`, `Country_CountryID`, `Province_ProvinceID`, `City_CityID`, `CityArea_CityAreaID`, `person_PersonID`) VALUES
(1, 1, 1, 4, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bloodingre`
--

CREATE TABLE `bloodingre` (
  `idingredient` int(11) NOT NULL,
  `incredientName` varchar(45) DEFAULT NULL,
  `incDescription` varchar(45) DEFAULT NULL,
  `incAmount` varchar(45) DEFAULT NULL,
  `Recipient_RecipientID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `CityID` int(11) NOT NULL,
  `CityName` varchar(45) DEFAULT NULL,
  `Province_ProvinceID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`CityID`, `CityName`, `Province_ProvinceID`) VALUES
(1, 'Karachi', 2),
(2, 'Lahore', 1),
(3, 'Multan', 1),
(4, 'Khanewal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cityarea`
--

CREATE TABLE `cityarea` (
  `CityAreaID` int(11) NOT NULL,
  `CityAreaName` varchar(150) DEFAULT NULL,
  `BlockNo` varchar(20) DEFAULT NULL,
  `StreetNo` varchar(20) DEFAULT NULL,
  `HouseNo` varchar(20) DEFAULT NULL,
  `City_CityID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cityarea`
--

INSERT INTO `cityarea` (`CityAreaID`, `CityAreaName`, `BlockNo`, `StreetNo`, `HouseNo`, `City_CityID`) VALUES
(1, 'madina town', '2', '2', '22', 4),
(2, 'shahrukn-e-alam', '23', '1', '126', 3);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `CountryID` int(11) NOT NULL,
  `CountryName` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`CountryID`, `CountryName`) VALUES
(1, 'Pakistan'),
(2, 'Palestine');

-- --------------------------------------------------------

--
-- Table structure for table `currentlocation`
--

CREATE TABLE `currentlocation` (
  `CurrentLocID` int(11) NOT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `DateTime` datetime DEFAULT NULL,
  `person_PersonID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `currentlocation`
--

INSERT INTO `currentlocation` (`CurrentLocID`, `latitude`, `longitude`, `DateTime`, `person_PersonID`) VALUES
(1, '51.5034070', '-0.1275920', '2016-05-14 17:16:24', 1),
(2, '51.5107392', '0.0623084', '2016-05-14 12:17:19', 2);

-- --------------------------------------------------------

--
-- Table structure for table `donorprofile`
--

CREATE TABLE `donorprofile` (
  `LastBleedDate` varchar(45) DEFAULT NULL,
  `QuantityGiven` varchar(45) DEFAULT NULL,
  `RecipientDetail` varchar(45) DEFAULT NULL,
  `DonorID` int(11) NOT NULL,
  `BodyWeight` varchar(45) DEFAULT NULL,
  `person_PersonID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `donorprofile`
--

INSERT INTO `donorprofile` (`LastBleedDate`, `QuantityGiven`, `RecipientDetail`, `DonorID`, `BodyWeight`, `person_PersonID`) VALUES
('2010-01-01', '300ml', 'Mr.Joseph', 1, '78', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hisdonor`
--

CREATE TABLE `hisdonor` (
  `idHisDonor` int(11) NOT NULL,
  `HisDonorcol` varchar(45) DEFAULT NULL,
  `DonorProfile_DonorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hisrecp`
--

CREATE TABLE `hisrecp` (
  `idHisRecp` int(11) NOT NULL,
  `HisRecpcol` varchar(45) DEFAULT NULL,
  `Recipient_RecipientID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `HistoryID` int(11) NOT NULL,
  `Recipient_RecipientID` int(11) NOT NULL,
  `DateTime` datetime DEFAULT NULL,
  `RecipientFlag` varchar(45) DEFAULT NULL,
  `DonorFlag` varchar(45) DEFAULT NULL,
  `DonorProfile_DonorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`HistoryID`, `Recipient_RecipientID`, `DateTime`, `RecipientFlag`, `DonorFlag`, `DonorProfile_DonorID`) VALUES
(1, 1, '2010-01-01 00:00:00', '1', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `PersonID` int(11) NOT NULL,
  `FirstName` varchar(45) NOT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `Date_of_birth` date NOT NULL,
  `Gender` varchar(6) NOT NULL,
  `bloodGroup` varchar(45) NOT NULL,
  `user_userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`PersonID`, `FirstName`, `LastName`, `Date_of_birth`, `Gender`, `bloodGroup`, `user_userID`) VALUES
(1, 'Muhammad jahanzeb', 'Khan', '1993-09-18', 'male', 'B+', 1),
(2, 'Joseph', 'Howie', '1992-01-01', 'male', 'O+', 2);

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE `province` (
  `ProvinceID` int(11) NOT NULL,
  `ProvinceName` varchar(45) DEFAULT NULL,
  `Country_CountryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `province`
--

INSERT INTO `province` (`ProvinceID`, `ProvinceName`, `Country_CountryID`) VALUES
(1, 'Punjab', 1),
(2, 'Sindh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `recipient`
--

CREATE TABLE `recipient` (
  `RecipientID` int(11) NOT NULL,
  `IsRecipient` varchar(45) DEFAULT NULL,
  `RecievedBloodDate` datetime DEFAULT NULL,
  `RecievedBloodQuantity` varchar(45) DEFAULT NULL,
  `RefferedByWhom` varchar(45) DEFAULT NULL,
  `CentreOrHospital` varchar(45) DEFAULT NULL,
  `ReasonCauseDisease` varchar(45) DEFAULT NULL,
  `person_PersonID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `recipient`
--

INSERT INTO `recipient` (`RecipientID`, `IsRecipient`, `RecievedBloodDate`, `RecievedBloodQuantity`, `RefferedByWhom`, `CentreOrHospital`, `ReasonCauseDisease`, `person_PersonID`) VALUES
(1, 'Yes', '2010-01-01 00:00:00', '300ml', 'Doctor.Razzaq', 'FatimidMultan', 'LungsPuncher', 2);

-- --------------------------------------------------------

--
-- Table structure for table `testname`
--

CREATE TABLE `testname` (
  `idTestName` int(11) NOT NULL,
  `TestDescription` varchar(45) DEFAULT NULL,
  `MinValue` varchar(45) DEFAULT NULL,
  `MaxValue` varchar(45) DEFAULT NULL,
  `NormalValue` varchar(45) DEFAULT NULL,
  `Other` varchar(45) DEFAULT NULL,
  `TestType_TestTypeID` int(11) NOT NULL,
  `TestType_DonorProfile_DonorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `testtype`
--

CREATE TABLE `testtype` (
  `TestTypeID` int(11) NOT NULL,
  `TestName` varchar(45) DEFAULT NULL,
  `TestDescription` varchar(45) DEFAULT NULL,
  `MinimumValue` varchar(45) DEFAULT NULL,
  `MaximumValue` varchar(45) DEFAULT NULL,
  `NormalValue` varchar(45) DEFAULT NULL,
  `TestDate` datetime DEFAULT NULL,
  `TestCentreOrHospital` varchar(45) DEFAULT NULL,
  `DonorProfile_DonorID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `emailConfirmFlag` varchar(45) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phoneNo` varchar(13) DEFAULT NULL,
  `phoneNoConfirm` varchar(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `email`, `emailConfirmFlag`, `password`, `phoneNo`, `phoneNoConfirm`) VALUES
(1, 'Jahanxbkhan@hotmail.com', '1', '$2y$10$jD5e9MFXuiBdzpXG7dUC3OJcFHsSiJQ0YTEJcsjuW/CvHMZP38qXS', '03216880801', '1'),
(2, 'youandmewillbeonfacebook@yahoo.com', '1', '25d55ad283aa400af464c76d713c07ad', '03216880802', '1'),
(3, 'kkkk@kk.com', NULL, '$2y$10$1zS7RkKn9abIjtzRtkI2Tu/EH5I1Cw8FuyMhxg4/LVAxZq.SkapSW', '03007654321', NULL),
(4, 'jj@jj.com', NULL, '$2y$10$jD5e9MFXuiBdzpXG7dUC3OJcFHsSiJQ0YTEJcsjuW/CvHMZP38qXS', '03007654322', NULL),
(5, 'kah@kah.com', NULL, '$2y$10$ckV9wH/ApUU85FN/m0znh.x0CO91ydwfbH1.CpeBO7bXqlOLr5CEa', '03007654323', NULL),
(6, 'zzz@zz.com', NULL, '$2y$10$A7Zs96XKQp7/2PlIKp0RmeeIOSKeXRAm.V1SR9kJ41wWuquzUbr0e', '03007654324', NULL),
(7, 'aaa@aa.com', NULL, '$2y$10$7E8iKqdOHp.lUCbLUS3lIenNV4k4fMexRiSZzAVrfSVoU5TgiM14G', '03007654325', NULL),
(8, 'shah@shah.com', NULL, '$2y$10$g9W4fpg8uQpJZNJoUkv2PONOvdzhWqLRDHntrD.mj6CDagJCBXiuu', '03216880800', NULL),
(9, 'talha@talha.com', NULL, '$2y$10$FUZTbWtShFUVeeldcV3D0OmLN5lGifELgUGagcEmKAOS3IV0ibzVC', '03007654312', NULL),
(10, 'qadeer@q.com', NULL, '$2y$10$zhoiCXM8DQo4I5rFE94d.unx0ZEewOXuDZs6NNNZk8mpkpMsNGsiy', '03216880803', NULL),
(11, 'ghq@r.com', NULL, '$2y$10$BInHEG19X6k/dbL0ApkLae/dnhq/NtsDdhfp4DGXJq5S/ZRVIjKNe', '03007654399', NULL),
(12, 'am@a.com', NULL, '$2y$10$gVyab0AHbmsZW8RZaH3UkeTtsQa/PogOW4WGYq3gX/3bASx1YV5Qy', '04331234567', NULL),
(13, 'az@a.com', NULL, '$2y$10$14/G52RoDwTDzB/lvdxQZeW40t.unT9n3H4YwXPx8bCBAxFNekjVW', '03216880822', NULL),
(14, 'bb@b.com', NULL, '$2y$10$5ZtCGHRM8KVcNO4i9DWkoO7YgAv6ks2h/LALMq49UUuKlwBpqjSDG', '09006880801', NULL),
(15, 'tt@t.com', NULL, '$2y$10$iDo8xBRD0O5BzjrLRFxANelLHeiSMOFYTgk/vjwnRqkzXvF0ZUPxa', '07006892473', NULL),
(16, '11@tt.com', NULL, '$2y$10$Moth0wfQocpatTb.HQtBEO/EnFFyUzHqUg1psrr1iRtKSz9zPSdU.', '09006880802', NULL),
(17, '2@tt.com', NULL, '$2y$10$CcYUSOyKtv1AgOohiHpYlug/wSXEZ1exHih..ZwOMdcDR6zFh6Q7S', '09006880803', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userrole`
--

CREATE TABLE `userrole` (
  `UserRoleID` int(11) NOT NULL,
  `UserInfo` varchar(45) DEFAULT NULL,
  `UserRights` varchar(45) DEFAULT NULL,
  `user_userID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userrole`
--

INSERT INTO `userrole` (`UserRoleID`, `UserInfo`, `UserRights`, `user_userID`) VALUES
(1, 'Admin', 'Full', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`AddressID`,`Country_CountryID`,`Province_ProvinceID`,`City_CityID`,`CityArea_CityAreaID`,`person_PersonID`),
  ADD KEY `fk_Address_Country1_idx` (`Country_CountryID`),
  ADD KEY `fk_Address_Province1_idx` (`Province_ProvinceID`),
  ADD KEY `fk_Address_City1_idx` (`City_CityID`),
  ADD KEY `fk_Address_CityArea1_idx` (`CityArea_CityAreaID`),
  ADD KEY `fk_Address_person1_idx` (`person_PersonID`);

--
-- Indexes for table `bloodingre`
--
ALTER TABLE `bloodingre`
  ADD PRIMARY KEY (`idingredient`,`Recipient_RecipientID`),
  ADD KEY `fk_Bloodingre_Recipient1_idx` (`Recipient_RecipientID`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`CityID`,`Province_ProvinceID`),
  ADD KEY `fk_City_Province1_idx` (`Province_ProvinceID`);

--
-- Indexes for table `cityarea`
--
ALTER TABLE `cityarea`
  ADD PRIMARY KEY (`CityAreaID`,`City_CityID`),
  ADD KEY `fk_CityArea_City1_idx` (`City_CityID`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`CountryID`);

--
-- Indexes for table `currentlocation`
--
ALTER TABLE `currentlocation`
  ADD PRIMARY KEY (`CurrentLocID`,`person_PersonID`),
  ADD KEY `fk_CurrentLocation_person1_idx` (`person_PersonID`);

--
-- Indexes for table `donorprofile`
--
ALTER TABLE `donorprofile`
  ADD PRIMARY KEY (`DonorID`,`person_PersonID`),
  ADD KEY `fk_DonorProfile_person1_idx` (`person_PersonID`);

--
-- Indexes for table `hisdonor`
--
ALTER TABLE `hisdonor`
  ADD PRIMARY KEY (`idHisDonor`,`DonorProfile_DonorID`),
  ADD KEY `fk_HisDonor_DonorProfile1_idx` (`DonorProfile_DonorID`);

--
-- Indexes for table `hisrecp`
--
ALTER TABLE `hisrecp`
  ADD PRIMARY KEY (`idHisRecp`,`Recipient_RecipientID`),
  ADD KEY `fk_HisRecp_Recipient1_idx` (`Recipient_RecipientID`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`HistoryID`,`Recipient_RecipientID`,`DonorProfile_DonorID`),
  ADD KEY `fk_History_Recipient1_idx` (`Recipient_RecipientID`),
  ADD KEY `fk_History_DonorProfile1_idx` (`DonorProfile_DonorID`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`PersonID`,`user_userID`),
  ADD KEY `fk_person_user1_idx` (`user_userID`);

--
-- Indexes for table `province`
--
ALTER TABLE `province`
  ADD PRIMARY KEY (`ProvinceID`,`Country_CountryID`),
  ADD KEY `fk_Province_Country1_idx` (`Country_CountryID`);

--
-- Indexes for table `recipient`
--
ALTER TABLE `recipient`
  ADD PRIMARY KEY (`RecipientID`,`person_PersonID`),
  ADD KEY `fk_Recipient_person1_idx` (`person_PersonID`);

--
-- Indexes for table `testname`
--
ALTER TABLE `testname`
  ADD PRIMARY KEY (`idTestName`,`TestType_TestTypeID`,`TestType_DonorProfile_DonorID`),
  ADD KEY `fk_TestName_TestType1_idx` (`TestType_TestTypeID`,`TestType_DonorProfile_DonorID`);

--
-- Indexes for table `testtype`
--
ALTER TABLE `testtype`
  ADD PRIMARY KEY (`TestTypeID`,`DonorProfile_DonorID`),
  ADD KEY `fk_TestType_DonorProfile1_idx` (`DonorProfile_DonorID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `phoneNo_UNIQUE` (`phoneNo`);

--
-- Indexes for table `userrole`
--
ALTER TABLE `userrole`
  ADD PRIMARY KEY (`UserRoleID`,`user_userID`),
  ADD KEY `fk_UserRole_user1_idx` (`user_userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `AddressID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `CityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cityarea`
--
ALTER TABLE `cityarea`
  MODIFY `CityAreaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `CountryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `currentlocation`
--
ALTER TABLE `currentlocation`
  MODIFY `CurrentLocID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `donorprofile`
--
ALTER TABLE `donorprofile`
  MODIFY `DonorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `HistoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `PersonID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `province`
--
ALTER TABLE `province`
  MODIFY `ProvinceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `recipient`
--
ALTER TABLE `recipient`
  MODIFY `RecipientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `testtype`
--
ALTER TABLE `testtype`
  MODIFY `TestTypeID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `userrole`
--
ALTER TABLE `userrole`
  MODIFY `UserRoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `fk_Address_City1` FOREIGN KEY (`City_CityID`) REFERENCES `city` (`CityID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Address_CityArea1` FOREIGN KEY (`CityArea_CityAreaID`) REFERENCES `cityarea` (`CityAreaID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Address_Country1` FOREIGN KEY (`Country_CountryID`) REFERENCES `country` (`CountryID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Address_Province1` FOREIGN KEY (`Province_ProvinceID`) REFERENCES `province` (`ProvinceID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Address_person1` FOREIGN KEY (`person_PersonID`) REFERENCES `person` (`PersonID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `bloodingre`
--
ALTER TABLE `bloodingre`
  ADD CONSTRAINT `fk_Bloodingre_Recipient1` FOREIGN KEY (`Recipient_RecipientID`) REFERENCES `recipient` (`RecipientID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `fk_City_Province1` FOREIGN KEY (`Province_ProvinceID`) REFERENCES `province` (`ProvinceID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `cityarea`
--
ALTER TABLE `cityarea`
  ADD CONSTRAINT `fk_CityArea_City1` FOREIGN KEY (`City_CityID`) REFERENCES `city` (`CityID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `currentlocation`
--
ALTER TABLE `currentlocation`
  ADD CONSTRAINT `fk_CurrentLocation_person1` FOREIGN KEY (`person_PersonID`) REFERENCES `person` (`PersonID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `donorprofile`
--
ALTER TABLE `donorprofile`
  ADD CONSTRAINT `fk_DonorProfile_person1` FOREIGN KEY (`person_PersonID`) REFERENCES `person` (`PersonID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hisdonor`
--
ALTER TABLE `hisdonor`
  ADD CONSTRAINT `fk_HisDonor_DonorProfile1` FOREIGN KEY (`DonorProfile_DonorID`) REFERENCES `donorprofile` (`DonorID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `hisrecp`
--
ALTER TABLE `hisrecp`
  ADD CONSTRAINT `fk_HisRecp_Recipient1` FOREIGN KEY (`Recipient_RecipientID`) REFERENCES `recipient` (`RecipientID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `fk_History_DonorProfile1` FOREIGN KEY (`DonorProfile_DonorID`) REFERENCES `donorprofile` (`DonorID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_History_Recipient1` FOREIGN KEY (`Recipient_RecipientID`) REFERENCES `recipient` (`RecipientID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `person`
--
ALTER TABLE `person`
  ADD CONSTRAINT `fk_person_user1` FOREIGN KEY (`user_userID`) REFERENCES `user` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `province`
--
ALTER TABLE `province`
  ADD CONSTRAINT `fk_Province_Country1` FOREIGN KEY (`Country_CountryID`) REFERENCES `country` (`CountryID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `recipient`
--
ALTER TABLE `recipient`
  ADD CONSTRAINT `fk_Recipient_person1` FOREIGN KEY (`person_PersonID`) REFERENCES `person` (`PersonID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `testname`
--
ALTER TABLE `testname`
  ADD CONSTRAINT `fk_TestName_TestType1` FOREIGN KEY (`TestType_TestTypeID`,`TestType_DonorProfile_DonorID`) REFERENCES `testtype` (`TestTypeID`, `DonorProfile_DonorID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `testtype`
--
ALTER TABLE `testtype`
  ADD CONSTRAINT `fk_TestType_DonorProfile1` FOREIGN KEY (`DonorProfile_DonorID`) REFERENCES `donorprofile` (`DonorID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `userrole`
--
ALTER TABLE `userrole`
  ADD CONSTRAINT `fk_UserRole_user1` FOREIGN KEY (`user_userID`) REFERENCES `user` (`userID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
