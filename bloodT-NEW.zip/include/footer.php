<!-- BEGIN FOOTER -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 space-mobile">
                    <!-- BEGIN ABOUT -->
                    <h2>About</h2>
                    <p class="margin-bottom-30">Our blood donors are ordinary people – high school students, factory and office workers, business executives, parents and grandparents, and people from every walk of life. But they share one thing – a generous spirit, a desire to give back to their community and help others. Blood donors play an integral role in the delivery of modern healthcare. Many lifesaving medical treatments and procedures involve blood transfusions and would not be possible without a safe and reliable blood supply.</p>
                    <div class="clearfix"></div>
                    <!-- END ABOUT -->


                </div>
                <div class="col-md-4 col-sm-4 space-mobile">
                    <!-- BEGIN CONTACTS -->
                    <h2>Contact Us</h2>
                    <address class="margin-bottom-40">
                        NFC-Institute of Engineering and Technology, <br />
                        Khanewal Road <br />
                        Multan,Punjab, Pakistan <br />
                        P: (061) 9220012 <br />
                        Email: <a href="mailto:jahanxbkhan@hotmail.com">admin@nfciet.edu.pk</a>
                    </address>
                    <!-- END CONTACTS -->

                    <!-- BEGIN SUBSCRIBE -->
                    <h2>Subscribe Us</h2>

                    <form action="#" class="form-subscribe">
                        <div class="input-group input-large">
                            <input class="form-control" type="text">
                            <span class="input-group-btn">
                                <button class="btn theme-btn" type="button">SUBSCRIBE</button>
                            </span>
                        </div>
                    </form>

                    <!-- END SUBSCRIBE -->
                </div>
                <div class="col-md-4 col-sm-4">
                    <!-- BEGIN TWITTER BLOCK -->
                    <h2>Latest Tweets</h2>
                    <dl class="dl-horizontal f-twitter">
                        <dt><i class="fa fa-twitter"></i></dt>
                        <dd>
                            <a href="#">@nfciet</a>
                            Vice Chancellor NFC(IET) will be meeting President of Pakistan.
                            <span>1 hour ago</span>
                        </dd>
                    </dl>
                    <dl class="dl-horizontal f-twitter">
                        <dt><i class="fa fa-twitter"></i></dt>
                        <dd>
                            <a href="#">@nfciet</a>
                            Admission prospectus will be avaliable from july'16
                            <span>5 hours ago</span>
                        </dd>
                    </dl>
                    <dl class="dl-horizontal f-twitter">
                        <dt><i class="fa fa-twitter"></i></dt>
                        <dd>
                            <a href="#">@nfciet</a>
                            Remote sensor and Virtual Assistant FYP projects are selected by Netsol.Ltd
                            <span>8 days ago</span>
                        </dd>
                    </dl>
                    <dl class="dl-horizontal f-twitter">
                        <dt><i class="fa fa-twitter"></i></dt>
                        <dd>
                            <a href="#">@nfciet</a>
                            Petroleum Engineering classes will commence from January 2015.
                            <span>a year ago</span>
                        </dd>
                    </dl>
                    <!-- END TWITTER BLOCK -->
                </div>
            </div>
        </div>
    </div>
    <!-- END FOOTER -->

    <!-- BEGIN COPYRIGHT -->
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-8">
                    <p>
                        <span class="margin-right-10">2016 © NFCIET(Department of Computer Science). ALL Rights Reserved.</span>
                        <a href="https://www.nfciet.edu.pk">Privacy Policy</a> | <a href="https://www.nfciet.edu.pk">Terms of Service</a>
                    </p>
                </div>
                <div class="col-md-4 col-sm-4">
                    <ul class="social-footer">
                        <li><a href="https://www.facebook.com/ietmultan/?fref=ts"><i class="fa fa-facebook"></i></a></li>


                        <li><a href="https://twitter.com/nfciet"><i class="fa fa-twitter"></i></a></li>

                        <li><a href="https://github.com/jahanxb"><i class="fa fa-github"></i></a></li>
                        <li><a href="https://www.youtube.com/watch?v=I7mrb77ioHA"><i class="fa fa-youtube"></i></a></li>
                                            </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- END COPYRIGHT -->

    <!-- Load javascripts at bottom, this will reduce page load time -->
    <!-- BEGIN CORE PLUGINS(REQUIRED FOR ALL PAGES) -->
    <!--[if lt IE 9]>
    <script src="assets/plugins/respond.min.js"></script>
    <![endif]-->
    <script src="assets/plugins/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="assets/plugins/jquery-migrate-1.2.1.min.js" type="text/javascript"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="assets/plugins/back-to-top.js"></script>
    <!-- END CORE PLUGINS -->

    <!-- BEGIN PAGE LEVEL JAVASCRIPTS(REQUIRED ONLY FOR CURRENT PAGE) -->
    <script type="text/javascript" src="assets/plugins/fancybox/source/jquery.fancybox.pack.js"></script>
    <script type="text/javascript" src="assets/plugins/revolution_slider/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
    <script type="text/javascript" src="assets/plugins/revolution_slider/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="assets/plugins/bxslider/jquery.bxslider.min.js"></script>
    <script src="assets/scripts/app.js"></script>
    <script src="assets/scripts/index.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function() {
            App.init();
            App.initBxSlider();
            Index.initRevolutionSlider();
        });
    </script>
    <!-- END PAGE LEVEL JAVASCRIPTS -->
</body>
<!-- END BODY -->
        </html>
